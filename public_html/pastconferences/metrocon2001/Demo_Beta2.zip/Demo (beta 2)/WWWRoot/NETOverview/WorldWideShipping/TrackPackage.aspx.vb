Public Class frmTrackPackage
    Inherits System.Web.UI.Page
    Protected WithEvents lblPackageToTrack As System.Web.UI.WebControls.Label
    Protected WithEvents txtTrackingNumber As System.Web.UI.WebControls.TextBox
    Protected WithEvents rfvTrackingNumber As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents cmdSubmit As System.Web.UI.WebControls.Button
    Protected WithEvents lblTrackingDetails As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then   ' Evals true first time browser hits the page	
            Me.lblPackageToTrack.Text = "Please enter a tracking number:"

            'Check the query string.
            If Request.QueryString.Item("TrackNum") <> "" Then
                Me.txtTrackingNumber.Text = Request.QueryString.Item("TrackNum")
                GetPackageDetails()
            End If
        End If
    End Sub

    Private Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSubmit.Click
        GetPackageDetails()
    End Sub

    Private Sub txtTrackingNumber_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTrackingNumber.TextChanged
        Me.txtTrackingNumber.Text = Me.txtTrackingNumber.Text.ToUpper()
    End Sub

    Private Sub GetPackageDetails()
        Dim packageTracker As New WWSPackageTrackServer.WWSPackageTrack()

        'Display tracking results.
        Me.lblTrackingDetails.Text = "Searching for details for <b>" & Me.txtTrackingNumber.Text & "</b>...<br><br>"
        Me.lblTrackingDetails.Text = Me.lblTrackingDetails.Text & packageTracker.GetShippingDetailsFor(Me.txtTrackingNumber.Text, True)
    End Sub
End Class

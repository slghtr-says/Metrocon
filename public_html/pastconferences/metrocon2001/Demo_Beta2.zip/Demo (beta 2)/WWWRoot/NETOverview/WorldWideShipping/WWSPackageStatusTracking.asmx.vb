Imports System.Web.Services
Imports System.Data.SqlClient

<WebService(Namespace:="http://BDM-NET-B2ENT/NETOverview/WorldWideShipping", _
Description:="World Wide Shipping offers many logistics services, including automated, electronic package tracking services such as this one for customers to integrate our logistics capabilities into thier own applications")> _
Public Class WWSPackageStatus
    Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
    End Sub

#End Region

    <WebMethod(Description:="The GetShippingStatusAsHTMLFor method returns an HTML string containing package and customer details.")> _
    Public Function GetShippingStatusAsHTMLFor(ByVal aTrackingNumber As String) As String
        'Instantiate the WWSCustomerTrack component, invoke it's method
    End Function
End Class

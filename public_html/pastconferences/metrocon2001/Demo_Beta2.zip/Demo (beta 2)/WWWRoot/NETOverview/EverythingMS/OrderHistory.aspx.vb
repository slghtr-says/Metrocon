Public Class OrderHistory
    Inherits System.Web.UI.Page
    Protected WithEvents lblShippingStatusHeader As System.Web.UI.WebControls.Label
    Protected WithEvents lblTrackingNumber As System.Web.UI.WebControls.Label
    Protected WithEvents hrefTrack1 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents hrefTrackBad As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblShippingStatus As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub handleTracking(ByVal sender As Object, ByVal e As System.EventArgs) Handles hrefTrack1.Click, hrefTrackBad.Click
        Dim trackingNumber As String
        Dim trackService As EverythingMS.TrackService.WWSPackageStatus

        'Get the tracking number from the sender.
        trackingNumber = sender.Text

        'Prepare headers.
        Me.lblShippingStatusHeader.Visible = True
        Me.lblTrackingNumber.Text = " for " & trackingNumber & ":"
        Me.lblTrackingNumber.Visible = True
        Me.lblShippingStatus.Visible = True

        'Attempt to contact the WebService for tracking details.
        Try
            trackService = New EverythingMS.TrackService.WWSPackageStatus()
            Me.lblShippingStatus.Text = trackService.GetShippingStatusAsHTMLFor(trackingNumber)
        Catch serviceError As Exception
            Me.lblShippingStatus.Text = "<b>Error:</b><br>" & serviceError.Message & " (" & serviceError.Source & ")."
        Finally
            trackService = Nothing
        End Try
    End Sub
End Class

Imports System.Data.SqlClient

Public Class CDataAccess
    Public Function Login(ByVal aUserLogon As String, ByVal aUserPassword As String) As CUserDetails
        Dim cnUser As SqlConnection
        Dim daUser As SqlCommand
        Dim drUser As SqlDataReader
        Dim strLogon As String
        Dim aUser As New CUserDetails()

        'Build logon query.
        strLogon = "SELECT * " & _
                   "FROM RegisteredUser " & _
                   "WHERE UserLogon = '" & aUserLogon & "' " & _
                   "  AND UserPassword = '" & aUserPassword & "'"

        Try
            'Connect to the database to validate user credentials.
            cnUser = New SqlConnection("server=(local);uid=sa;pwd=Passw0rd;database=EverythingMS;")
            cnUser.Open()
            daUser = New SqlCommand(strLogon, cnUser)
            drUser = daUser.ExecuteReader()

            'Interrogate the results.
            If drUser.Read() Then
                'Populate the user object.
                aUser.FirstName = drUser.Item("FirstName")
                aUser.LastName = drUser.Item("LastName")
                aUser.LastAccess = drUser.Item("LastAccessed")
            End If

            Return aUser
        Catch excGeneral As Exception
            'Append source call stack to the exception and forward to caller.
            excGeneral.Source = "EverythingMS.CDataAccess.Login::" & excGeneral.Source
            Throw excGeneral
        Finally
            'Release database resources.
            drUser.Close()
            daUser.Dispose()
            cnUser.Close()
        End Try
    End Function
End Class

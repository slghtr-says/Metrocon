Public Class CUserDetails
    Private myFirstName As String
    Private myLastName As String
    Private myLastAccess As Date

    Public Sub New()
        Me.FirstName = ""
        Me.LastName = ""
        Me.LastAccess = Date.Parse("1900-01-01")
    End Sub

    Public Sub New(ByVal aFirstName As String, ByVal aLastName As String, ByVal aLastAccess As Date)
        Me.FirstName = aFirstName
        Me.LastName = aLastName
        Me.LastAccess = aLastAccess
    End Sub

    Public Property FirstName() As String
        Get
            Return myFirstName
        End Get
        Set(ByVal Value As String)
            myFirstName = Value
        End Set
    End Property

    Public Property LastName() As String
        Get
            Return myLastName
        End Get
        Set(ByVal Value As String)
            myLastName = Value
        End Set
    End Property

    Public Property LastAccess() As Date
        Get
            Return myLastAccess
        End Get
        Set(ByVal Value As Date)
            myLastAccess = Value
        End Set
    End Property
End Class
using System;
using System.Diagnostics;
using CLRDemoResources;

namespace CSharpDemo
{
	/// <summary>
	///		This demonstration class will highlight no-touch deployment, cross-language
	///		interoperability and cross-language interoperability.
	/// </summary>
	public class CSharpBaseClass
	{
		public CSharpBaseClass()
		{
            System.Diagnostics.Debug.WriteLine("CSharpBaseClass constructor invoked.", "Inheritance activation path");
		}

    }
}
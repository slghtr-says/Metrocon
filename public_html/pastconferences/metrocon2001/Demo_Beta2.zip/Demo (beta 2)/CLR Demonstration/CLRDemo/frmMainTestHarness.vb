Imports CLRDemoResources
Imports CSharpDemo
Imports VBDemo

Public Class frmMainTestHarness
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Public Overloads Sub Dispose()
        MyBase.Dispose()
        If Not (components Is Nothing) Then
            components.Dispose()
        End If
    End Sub
    Private WithEvents cmdRun As System.Windows.Forms.Button
    Private WithEvents cmdExit As System.Windows.Forms.Button
    Private WithEvents mmMenu As System.Windows.Forms.MainMenu
    Private WithEvents miTest As System.Windows.Forms.MenuItem
    Private WithEvents miTestRun As System.Windows.Forms.MenuItem
    Private WithEvents miTestSep1 As System.Windows.Forms.MenuItem
    Private WithEvents miTestExit As System.Windows.Forms.MenuItem
    Private WithEvents miHelp As System.Windows.Forms.MenuItem
    Private WithEvents miHelpAbout As System.Windows.Forms.MenuItem

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMainTestHarness))
        Me.miTest = New System.Windows.Forms.MenuItem()
        Me.miTestRun = New System.Windows.Forms.MenuItem()
        Me.miTestSep1 = New System.Windows.Forms.MenuItem()
        Me.miTestExit = New System.Windows.Forms.MenuItem()
        Me.cmdRun = New System.Windows.Forms.Button()
        Me.mmMenu = New System.Windows.Forms.MainMenu()
        Me.miHelp = New System.Windows.Forms.MenuItem()
        Me.miHelpAbout = New System.Windows.Forms.MenuItem()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'miTest
        '
        Me.miTest.Index = 0
        Me.miTest.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.miTestRun, Me.miTestSep1, Me.miTestExit})
        Me.miTest.Text = "&Test"
        '
        'miTestRun
        '
        Me.miTestRun.Index = 0
        Me.miTestRun.Shortcut = System.Windows.Forms.Shortcut.CtrlR
        Me.miTestRun.Text = "&Run"
        '
        'miTestSep1
        '
        Me.miTestSep1.Index = 1
        Me.miTestSep1.Text = "-"
        '
        'miTestExit
        '
        Me.miTestExit.Index = 2
        Me.miTestExit.Shortcut = System.Windows.Forms.Shortcut.AltF4
        Me.miTestExit.Text = "E&xit"
        '
        'cmdRun
        '
        Me.cmdRun.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdRun.Location = New System.Drawing.Point(126, 6)
        Me.cmdRun.Name = "cmdRun"
        Me.cmdRun.Size = New System.Drawing.Size(75, 24)
        Me.cmdRun.TabIndex = 0
        Me.cmdRun.Text = "&Run Test"
        '
        'mmMenu
        '
        Me.mmMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.miTest, Me.miHelp})
        '
        'miHelp
        '
        Me.miHelp.Index = 1
        Me.miHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.miHelpAbout})
        Me.miHelp.Text = "&Help"
        '
        'miHelpAbout
        '
        Me.miHelpAbout.Index = 0
        Me.miHelpAbout.Text = "&About"
        '
        'cmdExit
        '
        Me.cmdExit.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmdExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdExit.Location = New System.Drawing.Point(210, 6)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(75, 24)
        Me.cmdExit.TabIndex = 1
        Me.cmdExit.Text = "E&xit"
        '
        'frmMainTestHarness
        '
        Me.AcceptButton = Me.cmdRun
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.cmdExit
        Me.ClientSize = New System.Drawing.Size(293, 38)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdExit, Me.cmdRun})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Menu = Me.mmMenu
        Me.Name = "frmMainTestHarness"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CLR Demonstration Test Harness"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub HandleExit(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdExit.Click, miTestExit.Click
        Application.Exit()
    End Sub

    Private Sub HandleRun(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRun.Click, miTestRun.Click
        'Notify the audience testing has commenced.
        Dim aMessageForm As New frmMessage("CLR and Inheritance Testing", "CLR demonstration commencing...")
        aMessageForm.ShowDialog(Me)
        aMessageForm = Nothing

        'CLR demonstration code will go here.
    End Sub

    Private Sub miHelpAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles miHelpAbout.Click
        Dim anAboutForm As New frmMessage("About CLR Demonstration Test Harness", _
                                          "This application serves as the test harness for a demonstration highlighting features of the Common Language Runtime (CLR)." & vbCrLf & vbCrLf & _
                                          "Features highlighted include no-touch deployment, cross-language interoperability and cross-language interoperability, as well as side-by-side versioning.")
        anAboutForm.ShowDialog(Me)

        'Clean up references.
        anAboutForm = Nothing
    End Sub
End Class

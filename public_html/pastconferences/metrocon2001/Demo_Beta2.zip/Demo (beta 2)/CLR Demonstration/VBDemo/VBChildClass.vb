Imports System.Diagnostics
Imports CLRDemoResources
Imports CSharpDemo

Public Class VBChildClass
    Inherits CSharpDemo.CSharpBaseClass

    Public Sub New()
        System.Diagnostics.Debug.WriteLine("VBChildClass constructor invoked.", "Inheritance activation path")
    End Sub

End Class
Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Initialize cmdGetDetails: hook up Shipping Date event handler.
        AddHandler cmdGetDetails.Click, New System.EventHandler(AddressOf handleGet_ShipDate)

        'Initialize format options, as well as event handler logic.
        Me.miFormatString.Checked = True
        Me.miFormatHTML.Checked = False
        Me.miFormatXML.Checked = False
        Me.cmdSave.Enabled = False
        Me.miTrackSave.Enabled = False
        AddHandler cmdGetDetails.Click, New System.EventHandler(AddressOf handleGet_ShipDetails_String)
        AddHandler miTrackGetDetails.Click, New System.EventHandler(AddressOf handleGet_ShipDetails_String)
        lastGetHandler = New System.EventHandler(AddressOf handleGet_ShipDetails_String)
        AddHandler cmdSave.Click, New System.EventHandler(AddressOf handleSave_String)
        AddHandler miTrackSave.Click, New System.EventHandler(AddressOf handleSave_String)
        lastSaveHandler = New System.EventHandler(AddressOf handleSave_String)
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents mmMain As System.Windows.Forms.MainMenu
    Friend WithEvents miTrack As System.Windows.Forms.MenuItem
    Friend WithEvents miFormat As System.Windows.Forms.MenuItem
    Friend WithEvents miHelp As System.Windows.Forms.MenuItem
    Friend WithEvents miTrackGetDetails As System.Windows.Forms.MenuItem
    Friend WithEvents miTrackSave As System.Windows.Forms.MenuItem
    Friend WithEvents miTrackSep1 As System.Windows.Forms.MenuItem
    Friend WithEvents miTrackExit As System.Windows.Forms.MenuItem
    Friend WithEvents miHelpAbout As System.Windows.Forms.MenuItem
    Friend WithEvents miFormatString As System.Windows.Forms.MenuItem
    Friend WithEvents miFormatHTML As System.Windows.Forms.MenuItem
    Friend WithEvents miFormatXML As System.Windows.Forms.MenuItem
    Friend WithEvents lblTrackNum As System.Windows.Forms.Label
    Friend WithEvents lblShipDate As System.Windows.Forms.Label
    Friend WithEvents lblShipDetails As System.Windows.Forms.Label
    Friend WithEvents txtTrackNum As System.Windows.Forms.TextBox
    Friend WithEvents txtShipDate As System.Windows.Forms.TextBox
    Friend WithEvents txtShipDetails As System.Windows.Forms.TextBox
    Friend WithEvents cmdGetDetails As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdExit As System.Windows.Forms.Button
    Friend WithEvents miHelpSep1 As System.Windows.Forms.MenuItem
    Friend WithEvents miHelpPlay As System.Windows.Forms.MenuItem
    Friend WithEvents miHelpPlayOpaque As System.Windows.Forms.MenuItem
    Friend WithEvents miHelpPlayTrans As System.Windows.Forms.MenuItem
    Friend WithEvents cdlSave As System.Windows.Forms.SaveFileDialog
    Friend WithEvents miHelpPlayMutate As System.Windows.Forms.MenuItem
    '
    'Private custom member variables.
    '
    Private lastGetHandler As System.EventHandler
    Private lastSaveHandler As System.EventHandler

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
        Me.lblTrackNum = New System.Windows.Forms.Label()
        Me.miTrack = New System.Windows.Forms.MenuItem()
        Me.miTrackGetDetails = New System.Windows.Forms.MenuItem()
        Me.miTrackSave = New System.Windows.Forms.MenuItem()
        Me.miTrackSep1 = New System.Windows.Forms.MenuItem()
        Me.miTrackExit = New System.Windows.Forms.MenuItem()
        Me.miHelpAbout = New System.Windows.Forms.MenuItem()
        Me.miHelpSep1 = New System.Windows.Forms.MenuItem()
        Me.miHelp = New System.Windows.Forms.MenuItem()
        Me.miHelpPlay = New System.Windows.Forms.MenuItem()
        Me.miHelpPlayOpaque = New System.Windows.Forms.MenuItem()
        Me.miHelpPlayTrans = New System.Windows.Forms.MenuItem()
        Me.miHelpPlayMutate = New System.Windows.Forms.MenuItem()
        Me.txtTrackNum = New System.Windows.Forms.TextBox()
        Me.miFormat = New System.Windows.Forms.MenuItem()
        Me.miFormatString = New System.Windows.Forms.MenuItem()
        Me.miFormatHTML = New System.Windows.Forms.MenuItem()
        Me.miFormatXML = New System.Windows.Forms.MenuItem()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.cdlSave = New System.Windows.Forms.SaveFileDialog()
        Me.lblShipDetails = New System.Windows.Forms.Label()
        Me.cmdGetDetails = New System.Windows.Forms.Button()
        Me.lblShipDate = New System.Windows.Forms.Label()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.txtShipDetails = New System.Windows.Forms.TextBox()
        Me.txtShipDate = New System.Windows.Forms.TextBox()
        Me.mmMain = New System.Windows.Forms.MainMenu()
        Me.SuspendLayout()
        '
        'lblTrackNum
        '
        Me.lblTrackNum.Location = New System.Drawing.Point(6, 7)
        Me.lblTrackNum.Name = "lblTrackNum"
        Me.lblTrackNum.Size = New System.Drawing.Size(114, 18)
        Me.lblTrackNum.TabIndex = 0
        Me.lblTrackNum.Text = "Tracking &Number:"
        '
        'miTrack
        '
        Me.miTrack.Index = 0
        Me.miTrack.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.miTrackGetDetails, Me.miTrackSave, Me.miTrackSep1, Me.miTrackExit})
        Me.miTrack.Text = "&Track"
        '
        'miTrackGetDetails
        '
        Me.miTrackGetDetails.Index = 0
        Me.miTrackGetDetails.Shortcut = System.Windows.Forms.Shortcut.CtrlG
        Me.miTrackGetDetails.Text = "&Get Details"
        '
        'miTrackSave
        '
        Me.miTrackSave.Index = 1
        Me.miTrackSave.Shortcut = System.Windows.Forms.Shortcut.CtrlS
        Me.miTrackSave.Text = "&Save"
        '
        'miTrackSep1
        '
        Me.miTrackSep1.Index = 2
        Me.miTrackSep1.Text = "-"
        '
        'miTrackExit
        '
        Me.miTrackExit.Index = 3
        Me.miTrackExit.Text = "E&xit"
        '
        'miHelpAbout
        '
        Me.miHelpAbout.Index = 2
        Me.miHelpAbout.Text = "&About..."
        '
        'miHelpSep1
        '
        Me.miHelpSep1.Index = 1
        Me.miHelpSep1.Text = "-"
        '
        'miHelp
        '
        Me.miHelp.Index = 2
        Me.miHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.miHelpPlay, Me.miHelpSep1, Me.miHelpAbout})
        Me.miHelp.Text = "&Help"
        '
        'miHelpPlay
        '
        Me.miHelpPlay.Index = 0
        Me.miHelpPlay.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.miHelpPlayOpaque, Me.miHelpPlayTrans, Me.miHelpPlayMutate})
        Me.miHelpPlay.Text = "&Play"
        '
        'miHelpPlayOpaque
        '
        Me.miHelpPlayOpaque.Index = 0
        Me.miHelpPlayOpaque.Text = "&Opaque"
        '
        'miHelpPlayTrans
        '
        Me.miHelpPlayTrans.Index = 1
        Me.miHelpPlayTrans.Text = "&Transparency"
        '
        'miHelpPlayMutate
        '
        Me.miHelpPlayMutate.Index = 2
        Me.miHelpPlayMutate.Text = "&Mutate Window"
        '
        'txtTrackNum
        '
        Me.txtTrackNum.Location = New System.Drawing.Point(132, 7)
        Me.txtTrackNum.Name = "txtTrackNum"
        Me.txtTrackNum.Size = New System.Drawing.Size(286, 20)
        Me.txtTrackNum.TabIndex = 1
        Me.txtTrackNum.Text = "X123456789Y987654321"
        '
        'miFormat
        '
        Me.miFormat.Index = 1
        Me.miFormat.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.miFormatString, Me.miFormatHTML, Me.miFormatXML})
        Me.miFormat.Text = "F&ormat"
        '
        'miFormatString
        '
        Me.miFormatString.Index = 0
        Me.miFormatString.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftS
        Me.miFormatString.Text = "&String"
        '
        'miFormatHTML
        '
        Me.miFormatHTML.Index = 1
        Me.miFormatHTML.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftH
        Me.miFormatHTML.Text = "&HTML"
        '
        'miFormatXML
        '
        Me.miFormatXML.Index = 2
        Me.miFormatXML.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftX
        Me.miFormatXML.Text = "&XML"
        '
        'cmdExit
        '
        Me.cmdExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdExit.Location = New System.Drawing.Point(340, 222)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.TabIndex = 8
        Me.cmdExit.Text = "E&xit"
        '
        'cdlSave
        '
        Me.cdlSave.InitialDirectory = "C:\"
        Me.cdlSave.Title = "Please Specify a File Name"
        '
        'lblShipDetails
        '
        Me.lblShipDetails.Location = New System.Drawing.Point(6, 67)
        Me.lblShipDetails.Name = "lblShipDetails"
        Me.lblShipDetails.Size = New System.Drawing.Size(114, 18)
        Me.lblShipDetails.TabIndex = 4
        Me.lblShipDetails.Text = "S&hipping Details:"
        '
        'cmdGetDetails
        '
        Me.cmdGetDetails.Location = New System.Drawing.Point(172, 222)
        Me.cmdGetDetails.Name = "cmdGetDetails"
        Me.cmdGetDetails.TabIndex = 6
        Me.cmdGetDetails.Text = "&Get Details"
        '
        'lblShipDate
        '
        Me.lblShipDate.Location = New System.Drawing.Point(6, 37)
        Me.lblShipDate.Name = "lblShipDate"
        Me.lblShipDate.Size = New System.Drawing.Size(114, 18)
        Me.lblShipDate.TabIndex = 2
        Me.lblShipDate.Text = "Shipping &Date"
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(256, 222)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.TabIndex = 7
        Me.cmdSave.Text = "&Save"
        '
        'txtShipDetails
        '
        Me.txtShipDetails.Location = New System.Drawing.Point(132, 67)
        Me.txtShipDetails.Multiline = True
        Me.txtShipDetails.Name = "txtShipDetails"
        Me.txtShipDetails.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtShipDetails.Size = New System.Drawing.Size(286, 149)
        Me.txtShipDetails.TabIndex = 5
        Me.txtShipDetails.Text = ""
        '
        'txtShipDate
        '
        Me.txtShipDate.Location = New System.Drawing.Point(132, 37)
        Me.txtShipDate.Name = "txtShipDate"
        Me.txtShipDate.Size = New System.Drawing.Size(286, 20)
        Me.txtShipDate.TabIndex = 3
        Me.txtShipDate.Text = ""
        '
        'mmMain
        '
        Me.mmMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.miTrack, Me.miFormat, Me.miHelp})
        '
        'frmMain
        '
        Me.AcceptButton = Me.cmdGetDetails
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.cmdExit
        Me.ClientSize = New System.Drawing.Size(424, 251)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdExit, Me.cmdSave, Me.cmdGetDetails, Me.txtShipDetails, Me.txtShipDate, Me.txtTrackNum, Me.lblShipDetails, Me.lblShipDate, Me.lblTrackNum})
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Menu = Me.mmMain
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Customer Package Tracking System"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub cdlSave_FileOk(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles cdlSave.FileOk
        'Change the mouse pointer to an hourglass.
        Me.Cursor = Cursors.WaitCursor

        'Attempt to save the the shipping details.
        If Not (e.Cancel) Then
            Try
                Dim savefile As New IO.StreamWriter(cdlSave.OpenFile())
                savefile.BaseStream.SetLength(Me.txtShipDetails.Text.Length)
                savefile.Write(Me.txtShipDetails.Text)
                savefile.Flush()
                savefile.Close()
            Catch saveExc As Exception
                MessageBox.Show("An error occurred:" & vbTab & saveExc.Message & vbCrLf & vbCrLf & _
                    vbTab & vbTab & "Source location:" & saveExc.Source, _
                    "File Save Error", _
                    MessageBoxButtons.OK, _
                    MessageBoxIcon.Exclamation, _
                    MessageBoxDefaultButton.Button1)
            End Try
        End If

        'Change the mouse pointer back to the default and release references.
        Me.Cursor = Cursors.Default
    End Sub

    Private Sub handleExit(ByVal sender As Object, ByVal e As System.EventArgs) Handles miTrackExit.Click, cmdExit.Click
        Application.Exit()
    End Sub

    Private Sub handleGet_ShipDate(ByVal sender As Object, ByVal e As System.EventArgs)
        'Get the shipping date from the customer tracking server.
        Dim objTracking As WWSCustomerTrackServer.WWSCustomerTrack

        Try
            'Attempt to fetch the shipping date.
            objTracking = New WWSCustomerTrackServer.WWSCustomerTrack()
            Me.txtShipDate.Text = objTracking.GetShipDateFor(Me.txtTrackNum.Text)
        Catch getError As Exception
            'Display errors in processing.
            MessageBox.Show(getError.Message, "Error: " & getError.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'Destroy allocated objects.
            objTracking = Nothing
        End Try
    End Sub

    Private Sub handleGet_ShipDetails_String(ByVal sender As Object, ByVal e As System.EventArgs)
        'Fetch shipping details from the tracking server as a string.
        Dim objTracking As WWSCustomerTrackServer.WWSCustomerTrack

        Try
            'Attempt to fetch the shipping details as string.
            objTracking = New WWSCustomerTrackServer.WWSCustomerTrack()
            Me.txtShipDetails.Text = objTracking.GetShippingDetailsFor(Me.txtTrackNum.Text, False)

            'Enable save commands once results are retrieved.
            Me.cmdSave.Enabled = True
            Me.miTrackSave.Enabled = True
        Catch getError As Exception
            'Display errors in processing.
            MessageBox.Show(getError.Message, "Error: " & getError.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'Destroy allocated objects.
            objTracking = Nothing
        End Try
    End Sub

    Private Sub handleGet_ShipDetails_HTML(ByVal sender As Object, ByVal e As System.EventArgs)
        'Fetch shipping details from the tracking server as HTML.
        Dim objTracking As WWSCustomerTrackServer.WWSCustomerTrack

        Try
            'Attempt to fetch the shipping details as HTML.
            objTracking = New WWSCustomerTrackServer.WWSCustomerTrack()
            Me.txtShipDetails.Text = objTracking.GetShippingDetailsFor(Me.txtTrackNum.Text, True)

            'Enable save commands once results are retrieved.
            Me.cmdSave.Enabled = True
            Me.miTrackSave.Enabled = True
        Catch getError As Exception
            'Display errors in processing.
            MessageBox.Show(getError.Message, "Error: " & getError.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'Destroy allocated objects.
            objTracking = Nothing
        End Try
    End Sub

    Private Sub handleGet_ShipDetails_XML(ByVal sender As Object, ByVal e As System.EventArgs)
        'Fetch shipping details from the tracking server as XML.
        Dim objTracking As WWSCustomerTrackServer.WWSCustomerTrack

        Try
            'Attempt to fetch the shipping details XML.
            objTracking = New WWSCustomerTrackServer.WWSCustomerTrack()
            Me.txtShipDetails.Text = objTracking.GetShippingDataFor(Me.txtTrackNum.Text).GetXml()

            'Enable save commands once results are retrieved.
            Me.cmdSave.Enabled = True
            Me.miTrackSave.Enabled = True
        Catch getError As Exception
            'Display errors in processing.
            MessageBox.Show(getError.Message, "Error: " & getError.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'Destroy allocated objects.
            objTracking = Nothing
        End Try
    End Sub

    Private Sub handleSave_String(ByVal sender As Object, ByVal e As System.EventArgs)
        'Save the details as a text (string) file; open the save file dialog for text files.
        cdlSave.Filter = "Text File|*.txt|All Files|*.*"
        cdlSave.FilterIndex = 1
        cdlSave.FileName = "ShippingDetails.txt"
        cdlSave.ShowDialog()
    End Sub

    Private Sub handleSave_HTML(ByVal sender As Object, ByVal e As System.EventArgs)
        'Save the details as an HTML file; open the save file dialog for HTML files.
        cdlSave.Filter = "HTML File|*.htm|All Files|*.*"
        cdlSave.FilterIndex = 1
        cdlSave.FileName = "ShippingDetails.htm"
        cdlSave.ShowDialog()
    End Sub

    Private Sub handleSave_XML(ByVal sender As Object, ByVal e As System.EventArgs)
        'Save the details as an XML file; open the save file dialog for XML files.
        cdlSave.Filter = "XML File|*.xml|All Files|*.*"
        cdlSave.FilterIndex = 1
        cdlSave.FileName = "ShippingDetails.xml"
        cdlSave.ShowDialog()
    End Sub

    Private Sub handleFormatMenu(ByVal sender As Object, ByVal e As System.EventArgs) Handles miFormatHTML.Click, miFormatString.Click, miFormatXML.Click
        'Disable get and save Buttons until processing has concluded, then clear TextBoxes.
        Me.cmdGetDetails.Enabled = False
        Me.cmdSave.Enabled = False
        Me.miTrackSave.Enabled = False
        Me.txtShipDate.Text = ""
        Me.txtShipDetails.Text = ""

        'Remove last event handlers.
        RemoveHandler cmdGetDetails.Click, lastGetHandler
        RemoveHandler miTrackGetDetails.Click, lastGetHandler
        RemoveHandler cmdSave.Click, lastSaveHandler
        RemoveHandler miTrackSave.Click, lastSaveHandler

        'Toggle state and event handlers.
        If sender Is Me.miFormatString Then
            Me.miFormatString.Checked = True
            Me.miFormatHTML.Checked = False
            Me.miFormatXML.Checked = False
            AddHandler cmdGetDetails.Click, New System.EventHandler(AddressOf handleGet_ShipDetails_String)
            AddHandler miTrackGetDetails.Click, New System.EventHandler(AddressOf handleGet_ShipDetails_String)
            AddHandler cmdSave.Click, New System.EventHandler(AddressOf handleSave_String)
            AddHandler miTrackSave.Click, New System.EventHandler(AddressOf handleSave_String)
            lastGetHandler = New System.EventHandler(AddressOf handleGet_ShipDetails_String)
            lastSaveHandler = New System.EventHandler(AddressOf handleSave_String)
        ElseIf sender Is Me.miFormatHTML Then
            Me.miFormatString.Checked = False
            Me.miFormatHTML.Checked = True
            Me.miFormatXML.Checked = False
            AddHandler cmdGetDetails.Click, New System.EventHandler(AddressOf handleGet_ShipDetails_HTML)
            AddHandler miTrackGetDetails.Click, New System.EventHandler(AddressOf handleGet_ShipDetails_HTML)
            AddHandler cmdSave.Click, New System.EventHandler(AddressOf handleSave_HTML)
            AddHandler miTrackSave.Click, New System.EventHandler(AddressOf handleSave_HTML)
            lastGetHandler = New System.EventHandler(AddressOf handleGet_ShipDetails_HTML)
            lastSaveHandler = New System.EventHandler(AddressOf handleSave_HTML)
        ElseIf sender Is Me.miFormatXML Then
            Me.miFormatString.Checked = False
            Me.miFormatHTML.Checked = False
            Me.miFormatXML.Checked = True
            AddHandler cmdGetDetails.Click, New System.EventHandler(AddressOf handleGet_ShipDetails_XML)
            AddHandler miTrackGetDetails.Click, New System.EventHandler(AddressOf handleGet_ShipDetails_XML)
            AddHandler cmdSave.Click, New System.EventHandler(AddressOf handleSave_XML)
            AddHandler miTrackSave.Click, New System.EventHandler(AddressOf handleSave_XML)
            lastGetHandler = New System.EventHandler(AddressOf handleGet_ShipDetails_XML)
            lastSaveHandler = New System.EventHandler(AddressOf handleSave_XML)
        End If

        'Processing has concluded; enable get.
        Me.cmdGetDetails.Enabled = True
    End Sub

    Private Sub miHelpAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles miHelpAbout.Click
        MessageBox.Show("This application allows the call center representatives to research shipping status for customers.", _
            "Customer Package Tracking System", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1)
    End Sub

    Private Sub miHelpPlayOpaque_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles miHelpPlayOpaque.Click
        Me.miHelpPlayOpaque.Checked = Not (Me.miHelpPlayOpaque.Checked)
        If Me.miHelpPlayOpaque.Checked Then
            Me.Opacity = 0.7
        Else
            Me.Opacity = 1
        End If
    End Sub

    Private Sub miHelpPlayTrans_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles miHelpPlayTrans.Click
        Me.miHelpPlayTrans.Checked = Not (Me.miHelpPlayTrans.Checked)
        If Me.miHelpPlayTrans.Checked Then
            Me.TransparencyKey = Color.White
        Else
            Me.TransparencyKey = Color.Empty
        End If
    End Sub

    Private Sub miHelpPlayMutate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles miHelpPlayMutate.Click
        Dim myPath As New Drawing2D.GraphicsPath()

        Me.miHelpPlayMutate.Checked = Not (Me.miHelpPlayMutate.Checked)
        If Me.miHelpPlayMutate.Checked Then
            myPath.AddArc(New Rectangle(0, 0, 250, 300), 0, 360)
            Me.Region = New Region(myPath)
        Else
            Me.Region = Nothing
        End If
    End Sub
End Class

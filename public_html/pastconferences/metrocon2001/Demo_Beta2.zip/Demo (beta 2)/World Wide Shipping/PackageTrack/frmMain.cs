using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using WWSPackageTrackServer;

namespace WWSPackageTrack
{
	public class frmMain : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Label lblTrackNum;
        private System.Windows.Forms.TextBox txtTrackNum;
        private System.Windows.Forms.GroupBox grpFormat;
        private System.Windows.Forms.RadioButton optString;
        private System.Windows.Forms.RadioButton optHTML;
        private System.Windows.Forms.TextBox txtDetails;
        private System.Windows.Forms.Button cmdGetDetails;
        private System.Windows.Forms.Button cmdSave;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.Button cmdExit;
		private System.Windows.Forms.RadioButton optXML;
        private System.Windows.Forms.SaveFileDialog cdlSave;
		private System.ComponentModel.IContainer components;

		/// <summary>
		/// Private custom member variables.
		/// </summary>
		private System.EventHandler lastGetHandler;
		private System.EventHandler lastSaveHandler;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

            //Initialize cmdGetDetails: hook up Shipping Date event handler.
			this.cmdGetDetails.Click += new System.EventHandler(this.cmdGetDetails_Clicked_ShippingDate);

			//Initialize formatting options, as well as event handler logic.
			this.optString.Checked = true;
			this.optHTML.Checked = false;
			this.cmdGetDetails.Click += new System.EventHandler(this.cmdGetDetails_Clicked_ShippingDetails_String);
			lastGetHandler = new System.EventHandler(this.cmdGetDetails_Clicked_ShippingDetails_String);
			this.cmdSave.Click += new System.EventHandler(this.cmdSave_Clicked_String);
			lastSaveHandler = new System.EventHandler(this.cmdSave_Clicked_String);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		public override void Dispose()
		{
			base.Dispose();
			if(components != null)	
				components.Dispose();
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMain));
            this.txtTrackNum = new System.Windows.Forms.TextBox();
            this.optString = new System.Windows.Forms.RadioButton();
            this.grpFormat = new System.Windows.Forms.GroupBox();
            this.optXML = new System.Windows.Forms.RadioButton();
            this.optHTML = new System.Windows.Forms.RadioButton();
            this.lblDate = new System.Windows.Forms.Label();
            this.cmdGetDetails = new System.Windows.Forms.Button();
            this.lblDetails = new System.Windows.Forms.Label();
            this.cdlSave = new System.Windows.Forms.SaveFileDialog();
            this.cmdExit = new System.Windows.Forms.Button();
            this.txtDetails = new System.Windows.Forms.TextBox();
            this.cmdSave = new System.Windows.Forms.Button();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.lblTrackNum = new System.Windows.Forms.Label();
            this.grpFormat.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtTrackNum
            // 
            this.txtTrackNum.Location = new System.Drawing.Point(114, 6);
            this.txtTrackNum.Name = "txtTrackNum";
            this.txtTrackNum.Size = new System.Drawing.Size(246, 20);
            this.txtTrackNum.TabIndex = 1;
            this.txtTrackNum.Text = "X123456789Y987654321";
            // 
            // optString
            // 
            this.optString.Checked = true;
            this.optString.Location = new System.Drawing.Point(12, 18);
            this.optString.Name = "optString";
            this.optString.Size = new System.Drawing.Size(104, 18);
            this.optString.TabIndex = 0;
            this.optString.TabStop = true;
            this.optString.Text = "S&tring";
            this.optString.Click += new System.EventHandler(this.optFormat_Clicked);
            // 
            // grpFormat
            // 
            this.grpFormat.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                    this.optXML,
                                                                                    this.optHTML,
                                                                                    this.optString});
            this.grpFormat.Location = new System.Drawing.Point(114, 60);
            this.grpFormat.Name = "grpFormat";
            this.grpFormat.Size = new System.Drawing.Size(246, 66);
            this.grpFormat.TabIndex = 4;
            this.grpFormat.TabStop = false;
            this.grpFormat.Text = "&Format";
            // 
            // optXML
            // 
            this.optXML.Location = new System.Drawing.Point(128, 18);
            this.optXML.Name = "optXML";
            this.optXML.Size = new System.Drawing.Size(104, 18);
            this.optXML.TabIndex = 2;
            this.optXML.Text = "&XML DataSet";
            this.optXML.Click += new System.EventHandler(this.optFormat_Clicked);
            // 
            // optHTML
            // 
            this.optHTML.Location = new System.Drawing.Point(12, 42);
            this.optHTML.Name = "optHTML";
            this.optHTML.Size = new System.Drawing.Size(104, 18);
            this.optHTML.TabIndex = 1;
            this.optHTML.Text = "&HTML";
            this.optHTML.Click += new System.EventHandler(this.optFormat_Clicked);
            // 
            // lblDate
            // 
            this.lblDate.Location = new System.Drawing.Point(6, 37);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(100, 18);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "Shipping &Date:";
            // 
            // cmdGetDetails
            // 
            this.cmdGetDetails.Location = new System.Drawing.Point(114, 192);
            this.cmdGetDetails.Name = "cmdGetDetails";
            this.cmdGetDetails.TabIndex = 7;
            this.cmdGetDetails.Text = "&Get Details";
            // 
            // lblDetails
            // 
            this.lblDetails.Location = new System.Drawing.Point(6, 133);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(100, 18);
            this.lblDetails.TabIndex = 5;
            this.lblDetails.Text = "Shipping Detai&ls:";
            // 
            // cdlSave
            // 
            this.cdlSave.InitialDirectory = "C:\\";
            this.cdlSave.Title = "Please Specify a File Name";
            this.cdlSave.FileOk += new System.ComponentModel.CancelEventHandler(this.cdlSave_FileOk);
            // 
            // cmdExit
            // 
            this.cmdExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdExit.Location = new System.Drawing.Point(285, 192);
            this.cmdExit.Name = "cmdExit";
            this.cmdExit.TabIndex = 9;
            this.cmdExit.Text = "E&xit";
            this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
            // 
            // txtDetails
            // 
            this.txtDetails.Location = new System.Drawing.Point(114, 132);
            this.txtDetails.Multiline = true;
            this.txtDetails.Name = "txtDetails";
            this.txtDetails.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDetails.Size = new System.Drawing.Size(246, 54);
            this.txtDetails.TabIndex = 6;
            this.txtDetails.Text = "";
            // 
            // cmdSave
            // 
            this.cmdSave.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdSave.Enabled = false;
            this.cmdSave.Location = new System.Drawing.Point(200, 192);
            this.cmdSave.Name = "cmdSave";
            this.cmdSave.TabIndex = 8;
            this.cmdSave.Text = "&Save";
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(114, 36);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(246, 20);
            this.txtDate.TabIndex = 3;
            this.txtDate.Text = "";
            // 
            // lblTrackNum
            // 
            this.lblTrackNum.Location = new System.Drawing.Point(6, 7);
            this.lblTrackNum.Name = "lblTrackNum";
            this.lblTrackNum.Size = new System.Drawing.Size(100, 18);
            this.lblTrackNum.TabIndex = 0;
            this.lblTrackNum.Text = "Tracking &Number:";
            // 
            // frmMain
            // 
            this.AcceptButton = this.cmdGetDetails;
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.CancelButton = this.cmdExit;
            this.ClientSize = new System.Drawing.Size(364, 219);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.cmdExit,
                                                                          this.lblDetails,
                                                                          this.lblDate,
                                                                          this.txtDate,
                                                                          this.cmdSave,
                                                                          this.cmdGetDetails,
                                                                          this.txtDetails,
                                                                          this.grpFormat,
                                                                          this.txtTrackNum,
                                                                          this.lblTrackNum});
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Package Tracking";
            this.grpFormat.ResumeLayout(false);
            this.ResumeLayout(false);

        }
		#endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() 
        {
            Application.Run(new frmMain());
        }

		private void cdlSave_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
		{
			//Change the cursor to an hourglass.
			this.Cursor = Cursors.WaitCursor;

			if (!e.Cancel)
			{
				try
				{
					StreamWriter saveFile = new StreamWriter(cdlSave.OpenFile());
					saveFile.BaseStream.SetLength(this.txtDetails.Text.Length);
					saveFile.Write(this.txtDetails.Text);
					saveFile.Flush();
					saveFile.Close();
				}
				catch (Exception saveExc)
				{
					MessageBox.Show("An error occurred:\t" + saveExc.Message + "\r\n\r\n\t\tSource location:" + saveExc.Source, "File Save Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
				}
			}

			//Change the cursor to the default cursor.
			this.Cursor = Cursors.Default;
		}

		private void cmdGetDetails_Clicked_ShippingDate(object sender, System.EventArgs e)
        {
			//Get the shipping date from the tracking server.
            WWSPackageTrackServer.WWSPackageTrack objTrackPackage;

            try
            {
                //Attempt to fetch the shipping date.
                objTrackPackage = new WWSPackageTrackServer.WWSPackageTrack();
                this.txtDate.Text = objTrackPackage.GetShipDateFor(this.txtTrackNum.Text);
            }
            catch (Exception aSystemError)
            {
                //Display errors in processing.
                MessageBox.Show(aSystemError.Message, "Error: " + aSystemError.Source, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //Destroy allocated objects.
                objTrackPackage = null;
            }
        }

        private void cmdGetDetails_Clicked_ShippingDetails_String(object sender, System.EventArgs e)
        {
			//Fetch shipping details from the tracking server as a string.
            WWSPackageTrackServer.WWSPackageTrack objTrackPackage;

            try
            {
                //Attempt to fetch the shipping details as string.
                objTrackPackage = new WWSPackageTrackServer.WWSPackageTrack();
                this.txtDetails.Text = objTrackPackage.GetShippingDetailsFor(this.txtTrackNum.Text, false);

				//Enable the save button when details are successfully retrieved.
				this.cmdSave.Enabled = true;
            }
            catch (Exception aSystemError)
            {
                //Display errors in processing.
                MessageBox.Show(aSystemError.Message, "Error: " + aSystemError.Source, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //Destroy allocated objects.
                objTrackPackage = null;
            }
        }

		private void cmdGetDetails_Clicked_ShippingDetails_HTML(object sender, System.EventArgs e)
		{
			//Fetch shipping details from the tracking server as an HTML string.
			WWSPackageTrackServer.WWSPackageTrack objTrackPackage;

			try
			{
				//Attempt to fetch the shipping details as HTML.
				objTrackPackage = new WWSPackageTrackServer.WWSPackageTrack();
				this.txtDetails.Text = objTrackPackage.GetShippingDetailsFor(this.txtTrackNum.Text, true);

				//Enable the save button when details are successfully retrieved.
				this.cmdSave.Enabled = true;
			}
			catch (Exception aSystemError)
			{
				//Display errors in processing.
				MessageBox.Show(aSystemError.Message, "Error: " + aSystemError.Source, MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally
			{
				//Destroy allocated objects.
				objTrackPackage = null;
			}
		}

        private void cmdGetDetails_Clicked_ShippingDetails_XMLDataSet(object sender, System.EventArgs e)
        {
            //Fetch a DataSet from the tracking server.
            WWSPackageTrackServer.WWSPackageTrack objTrackPackage;

            try
            {
                //Attempt to fetch the shipping details as an XML document (via DataSet.GetXML).
                objTrackPackage = new WWSPackageTrackServer.WWSPackageTrack();
                this.txtDetails.Text = objTrackPackage.GetShippingDataFor(this.txtTrackNum.Text).GetXml();

                //Enable the save button when details are successfully retrieved.
                this.cmdSave.Enabled = true;
            }
            catch (Exception aSystemError)
            {
                //Display errors in processing.
                MessageBox.Show(aSystemError.Message, "Error: " + aSystemError.Source, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //Destroy allocated objects.
                objTrackPackage = null;
            }
        }

        private void cmdSave_Clicked_String(object sender, System.EventArgs e)
		{
			//Save the details as a text (string) file; open the save file dialog for text files.
			cdlSave.Filter = "Text File|*.txt|All Files|*.*";
			cdlSave.FilterIndex = 1;
			cdlSave.FileName = "ShippingDetails.txt";
			cdlSave.ShowDialog();
		}

		private void cmdSave_Clicked_HTML(object sender, System.EventArgs e)
		{
			//Save the details as an HTML file; open the save file dialog for HTML files.
			cdlSave.Filter = "HTML File|*.htm|All Files|*.*";
			cdlSave.FilterIndex = 1;
			cdlSave.FileName = "ShippingDetails.htm";
			cdlSave.ShowDialog();
		}

		private void cmdSave_Clicked_XML(object sender, System.EventArgs e)
		{
			//Save the details as an XML file; open the save file dialog for XML files.
			cdlSave.Filter = "XML File|*.xml|All Files|*.*";
			cdlSave.FilterIndex = 1;
			cdlSave.FileName = "ShippingDetails.xml";
			cdlSave.ShowDialog();
		}

		private void cmdExit_Click(object sender, System.EventArgs e)
        {
            this.Dispose();
            Application.Exit();
        }

		private void optFormat_Clicked (object sender, System.EventArgs e)
		{
			//Disallow get and save buttons and clear results.
            this.cmdGetDetails.Enabled = false;
			this.cmdSave.Enabled = false;
            this.txtDate.Text = "";
			this.txtDetails.Text = "";

            //Remove last event handlers.
            cmdGetDetails.Click -= lastGetHandler;
            this.cmdSave.Click -= lastSaveHandler;

			//Toggle event handlers based on  format chosen.
			if (sender.Equals(this.optHTML))
			{
				//Toggle cmdGetDetails event handler to HTML handler.
				cmdGetDetails.Click += new System.EventHandler(this.cmdGetDetails_Clicked_ShippingDetails_HTML);
				lastGetHandler = new System.EventHandler(this.cmdGetDetails_Clicked_ShippingDetails_HTML);

				//Toggle cmdSave event handler to HTML handler.
				this.cmdSave.Click += new System.EventHandler(this.cmdSave_Clicked_HTML);
				lastSaveHandler = new System.EventHandler(this.cmdSave_Clicked_HTML);
			}
			else if (sender.Equals(this.optString))
			{
				//Toggle cmdGetDetails event handler to String handler.
				cmdGetDetails.Click += new System.EventHandler(this.cmdGetDetails_Clicked_ShippingDetails_String);
				lastGetHandler = new System.EventHandler(this.cmdGetDetails_Clicked_ShippingDetails_String);

				//Toggle cmdSave event handler to String handler.
				this.cmdSave.Click += new System.EventHandler(this.cmdSave_Clicked_String);
				lastSaveHandler = new System.EventHandler(this.cmdSave_Clicked_String);
			}
			else if (sender.Equals(this.optXML))
			{
				//Toggle cmdGetDetails event handler to XML handler.
				cmdGetDetails.Click += new System.EventHandler(this.cmdGetDetails_Clicked_ShippingDetails_XMLDataSet);
				lastGetHandler = new System.EventHandler(this.cmdGetDetails_Clicked_ShippingDetails_XMLDataSet);

				//Toggle cmdSave event handler to XML handler.
				this.cmdSave.Click += new System.EventHandler(this.cmdSave_Clicked_XML);
				lastSaveHandler = new System.EventHandler(this.cmdSave_Clicked_XML);
			}

            //Restore get button to allow processing.
            this.cmdGetDetails.Enabled = true;
		}
	}
}

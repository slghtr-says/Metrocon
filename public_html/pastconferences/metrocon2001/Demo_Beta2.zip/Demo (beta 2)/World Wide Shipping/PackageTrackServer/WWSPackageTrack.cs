using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace WWSPackageTrackServer
{
	/// <summary>
	/// .NET Demo: Package Tracking Service for World Wide Shipping (WWS), a fictional shipping vendor.
	/// </summary>
	public class WWSPackageTrack
	{
        protected string strConnection;

        /// <summary>
        /// This is the default constructor.
        /// </summary>
		public WWSPackageTrack()
		{
            //This class represents a middle-tier component. Maintain minimal state.
            strConnection = "server=(local);uid=sa;pwd=Passw0rd;database=WorldWideShipping;";
        }

        /// <summary>
        ///		This constructor allows the consumer to override the primary database connection string.
        /// </summary>
        /// <param name="aConnectionString">
        ///		This parameter allows consumers of the class to override the default connection string.
        /// </param>
        public WWSPackageTrack(string aConnectionString)
        {
            strConnection = aConnectionString;
        }

        /// <summary>
        ///		Use ADO.NET SQL Server-specific objects to get the shipping date for the specified tracking number.
        /// </summary>
        /// <param name="aTrackingNumber">
        ///		This parameter specifies the tracking number for which tracking information is requested.
        /// </param>
        virtual public string GetShipDateFor(string aTrackingNumber)
        {
            //Set up default values.
            System.DateTime dtDefaultDate = System.DateTime.Parse("01/01/1900");
            System.DateTime dtShipDate = dtDefaultDate.Date;
            string strShipDateDetails = "";

            //Set up data access objects.
            SqlConnection cnWWSLogistics;
            SqlDataAdapter cmdShipDate;
            DataSet dsShipDate;

            //Access the database for the shipping date.
            try
            {
                //Connect and fetch the shipping date.
                cnWWSLogistics = new SqlConnection(strConnection);
                cmdShipDate = new SqlDataAdapter("SELECT ShipDate FROM Tracking WHERE TrackingNumber = '" + aTrackingNumber + "'", cnWWSLogistics);
                dsShipDate = new DataSet();
                cmdShipDate.Fill(dsShipDate, "Tracking");

                //Extract the shipping date.
                foreach (DataRow aRow in dsShipDate.Tables["Tracking"].Rows)
                {
                    //Only the last date fetched will be returned. Note: only one date should exist.
                    dtShipDate = System.DateTime.Parse(aRow["ShipDate"].ToString());
                }

                //Close connections to the database.
                cnWWSLogistics.Close();
            }
            catch (Exception aDataAccessError)
            {
                aDataAccessError.Source = "WWSPackageTrackServer.WWSPackageTrack.GetShipDateFor::" + aDataAccessError.Source;
                throw aDataAccessError;
            }
            finally
            {
                //Clean up processing.
                if (dtShipDate.Equals(dtDefaultDate))
                {
                    strShipDateDetails = "The tracking number was not found in the system.";
                }
                else
                {
                    strShipDateDetails = dtShipDate.ToString();
                }

                //Destroy allocated objects.
                cnWWSLogistics = null;
                cmdShipDate = null;
                dsShipDate = null;
            }

            return strShipDateDetails;
        }

		/// <summary>
		///		Use ADO.NET SQL Server-specific objects to get the shipping details for the specified tracking number.
		///		This method returns a formatted string in either plain text or HTML format.
		/// </summary>
        /// <param name="aTrackingNumber">
        ///		This parameter specifies the tracking number for which tracking information is requested.
        /// </param>
        /// <param name="asHTML">
        ///		This parameter specifies whether the results should be formatted as plain text or HTML.
        /// </param>
		virtual public string GetShippingDetailsFor(string aTrackingNumber, bool asHTML)
		{
			//Set up default values.
			System.String strShippingDetails = "";
			if (asHTML == true)
			{
				strShippingDetails = "Details for tracking number <b>" + aTrackingNumber + "</b> are unavailable at this time.";
			}
			else
			{
				strShippingDetails = "Details for tracking number " + aTrackingNumber + " are unavailable at this time.";
			}

			//Set up data access objects.
			SqlConnection cnWWSLogistics;
			SqlDataAdapter cmdShipDetails;
			DataSet dsShipDetails;

			//Access the database for shipping details.
			try
			{
				//Connect and fetch shipping details.
				cnWWSLogistics = new SqlConnection(strConnection);
				cmdShipDetails = new SqlDataAdapter("SELECT ShipDate, ArrivalDate, ShipToAddress, ShipToState, ShipToZip FROM Tracking WHERE TrackingNumber = '" + aTrackingNumber + "'", cnWWSLogistics);
				dsShipDetails = new DataSet();
				cmdShipDetails.Fill(dsShipDetails, "Tracking");

				//Extract the shipping details.
				foreach (DataRow aRow in dsShipDetails.Tables["Tracking"].Rows)
				{
					//Initialize working variables.
					strShippingDetails = "";
					DateTime dtShipDate = DateTime.Parse(aRow["ShipDate"].ToString());
					DateTime dtArrivalDate = DateTime.Parse(aRow["ArrivalDate"].ToString());

                    //Build formatted results.
					if (asHTML == true)
					{
						strShippingDetails = "<table border='0'>";
						strShippingDetails += "<tr valign='top'><td>The package shipped on:</td><td>" + dtShipDate.Month + "-" + dtShipDate.Day + "-" + dtShipDate.Year + "</td></tr>";
						strShippingDetails += "<tr valign='top'><td>The estimated arrival date is:</td><td>" + dtArrivalDate.Month + "-" + dtArrivalDate.Day + "-" + dtArrivalDate.Year + "</td></tr>";
						strShippingDetails += "<tr valign='top'><td></td><td></td></tr>";
						strShippingDetails += "<tr valign='top'><td>The package was shipped to:</td><td>" + aRow["ShipToAddress"].ToString() + "<br>" + aRow["ShipToState"].ToString() + " " + aRow["ShipToZip"].ToString().Trim() + "</td></tr>";
						strShippingDetails += "</table><br><br>";
					}
					else
					{
						strShippingDetails += "The package shipped on " + dtShipDate.Month + "-" + dtShipDate.Day + "-" + dtShipDate.Year + ".\r\n";
						strShippingDetails += "The estimated arrival date is " + dtArrivalDate.Month + "-" + dtArrivalDate.Day + "-" + dtArrivalDate.Year + ".\r\n\r\n";
						strShippingDetails += "The package was shipped to:\r\n\t" + aRow["ShipToAddress"].ToString() + "\r\n\t" + aRow["ShipToState"].ToString() + " " + aRow["ShipToZip"].ToString().Trim();
					}
				}

				//Close connections to the database.
				cnWWSLogistics.Close();
			}
			catch (Exception aDataAccessError)
			{
				aDataAccessError.Source = "WWSPackageTrackServer.WWSPackageTrack.GetShippingDetailsFor::" + aDataAccessError.Source;
				throw aDataAccessError;
			}
			finally
			{
				//Destroy allocated objects.
				cnWWSLogistics = null;
				cmdShipDetails = null;
				dsShipDetails = null;
			}

			return strShippingDetails;
		}
		/// <summary>
		///		Use ADO.NET SQL Server-specific objects to get the shipping details for the specified tracking number.
		///		This method returns a DataSet to allow the consumer to parse the results as they see fit.
		/// </summary>
        /// <param name="aTrackingNumber">
        ///		This parameter specifies the tracking number for which tracking information is requested.
        /// </param>
		virtual public DataSet GetShippingDataFor(string aTrackingNumber)
		{
			//Set up data access objects.
			SqlConnection cnWWSLogistics;
			SqlDataAdapter cmdShipDetails;
			DataSet dsShipDetails;

			//Access the database for the shipping details.
			try
			{
				//Connect and fetch the shipping details.
				cnWWSLogistics = new SqlConnection(strConnection);
				cmdShipDetails = new SqlDataAdapter("SELECT ShipDate, ArrivalDate, ShipToAddress, ShipToState, ShipToZip FROM Tracking WHERE TrackingNumber = '" + aTrackingNumber + "'", cnWWSLogistics);
				dsShipDetails = new DataSet();
				cmdShipDetails.Fill(dsShipDetails, "Tracking");

				//Close connections to the database.
				cnWWSLogistics.Close();
			}
			catch (Exception aDataAccessError)
			{
				aDataAccessError.Source = "WWSPackageTrackServer.WWSPackageTrack.GetShippingDataFor::" + aDataAccessError.Source;
				throw aDataAccessError;
			}
			finally
			{
				//Destroy allocated objects.
				cnWWSLogistics = null;
				cmdShipDetails = null;
			}

			return dsShipDetails;
		}

	}
}

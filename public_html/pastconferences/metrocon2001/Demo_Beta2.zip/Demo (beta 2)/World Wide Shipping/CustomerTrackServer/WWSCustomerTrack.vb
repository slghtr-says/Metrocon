Imports System.Data
Imports System.Data.SqlClient
Imports WWSPackageTrackServer

Public Class WWSCustomerTrack
    Inherits WWSPackageTrackServer.WWSPackageTrack
    'This class represents a middle-tier component. Maintain minimal state.
    Protected Shadows strConnection As String

    Public Sub New()
        'This is the default constructor.
        strConnection = MyBase.strConnection
    End Sub

    Public Sub New(ByVal aConnection As String)
        'This constructor allows the consumer to override the primary database connection string.
        strConnection = aConnection
    End Sub

    Public Overrides Function GetShippingDetailsFor(ByVal aTrackingNumber As String, ByVal asHTML As Boolean) As String
        Dim cnCustomerDB As SqlConnection
        Dim cmdCustDetail As SqlCommand
        Dim daCustDetail As SqlDataAdapter
        Dim parmTrackingNumber As SqlParameter
        Dim dsCustDetail As DataSet
        Dim singleRow As DataRow
        Dim strResults As String = ""

        'Initialize the result string; assume an error.
        strResults = "Customer information not on file."

        Try
            'Connect to the database.
            cnCustomerDB = New SqlConnection(strConnection)
            cnCustomerDB.Open()

            'Prepare the stored procedure SqlParameter.
            parmTrackingNumber = New SqlParameter("@TrackingNumber", SqlDbType.Char, aTrackingNumber.Length)
            parmTrackingNumber.Value = aTrackingNumber

            'Prepare a SqlCommand to get the customer details from a tracking number.
            cmdCustDetail = New SqlCommand()
            cmdCustDetail.Connection = cnCustomerDB
            cmdCustDetail.CommandType = CommandType.StoredProcedure
            cmdCustDetail.CommandText = "spGetCustomerDetails"
            cmdCustDetail.Parameters.Add(parmTrackingNumber)

            'Prepare a SqlDataAdapter and DataSet, and fill the DataSet.
            daCustDetail = New SqlDataAdapter(cmdCustDetail)
            dsCustDetail = New DataSet()
            daCustDetail.Fill(dsCustDetail, "Customer")

            'Extract customer details.
            For Each singleRow In dsCustDetail.Tables("Customer").Rows
                'Initialize working variables.
                strResults = ""

                If asHTML Then
                    'Prepare customer information as HTML.
                    strResults &= "<table border='0'>"
                    strResults &= "<tr valign='top'><td>Package details prepared for:</td><td>" & singleRow("LastName") & ", " & singleRow("FirstName") & "</td></tr>"
                    strResults &= "<tr valign='top'><td>&nbsp;</td><td>" & singleRow("Company") & "</td></tr>"
                    strResults &= "<tr valign='top'><td>&nbsp;</td><td>" & singleRow("PrimaryPhone") & "</td></tr>"
                    strResults &= "</table>"
                Else
                    'Prepare customer information as a string.
                    strResults &= "Package details prepared for:" & vbCrLf & _
                        vbTab & singleRow("LastName") & ", " & singleRow("FirstName") & vbCrLf & _
                        vbTab & singleRow("Company") & vbCrLf & _
                        vbTab & singleRow("PrimaryPhone")
                End If
            Next

            'Call base class, appending results to local variable, and return results.
            GetShippingDetailsFor = strResults & vbCrLf & vbCrLf & MyBase.GetShippingDetailsFor(aTrackingNumber, asHTML)
        Catch excDataAccess As Exception
            excDataAccess.Source = "WWSCustomerTrackServer.WWSCustomerTrack.GetShippingDetailsFor::" & excDataAccess.Source
            Throw excDataAccess
        Finally
            'Close all connections.
            cnCustomerDB.Close()

            'Destroy all references.
            cnCustomerDB = Nothing
            cmdCustDetail = Nothing
            parmTrackingNumber = Nothing
            dsCustDetail = Nothing
        End Try
    End Function

    Public Overrides Function GetShippingDataFor(ByVal aTrackingNumber As String) As System.Data.DataSet
        Dim cnCustomerDB As SqlConnection
        Dim cmdCustDetail As SqlCommand
        Dim daCustDetail As SqlDataAdapter
        Dim parmTrackingNumber As SqlParameter
        Dim dsFullDetails As DataSet

        Try
            'Get package tracking details from base class.
            dsFullDetails = MyBase.GetShippingDataFor(aTrackingNumber)

            'Connect to the database.
            cnCustomerDB = New SqlConnection(strConnection)
            cnCustomerDB.Open()

            'Prepare the stored procedure SqlParameter.
            parmTrackingNumber = New SqlParameter("@TrackingNumber", SqlDbType.Char, aTrackingNumber.Length)
            parmTrackingNumber.Value = aTrackingNumber

            'Prepare a SqlCommand to get the customer details from a tracking number.
            cmdCustDetail = New SqlCommand()
            cmdCustDetail.Connection = cnCustomerDB
            cmdCustDetail.CommandType = CommandType.StoredProcedure
            cmdCustDetail.CommandText = "spGetCustomerDetails"
            cmdCustDetail.Parameters.Add(parmTrackingNumber)

            'Prepare a SqlDataAdapter, then append the customer information to the existing DataSet.
            daCustDetail = New SqlDataAdapter(cmdCustDetail)
            daCustDetail.Fill(dsFullDetails, "Customer")

            'Return results.
            GetShippingDataFor = dsFullDetails
        Catch excDataAccess As Exception
            excDataAccess.Source = "WWSCustomerTrackServer.WWSCustomerTrack.GetShipDateFor::" & excDataAccess.Source
            Throw excDataAccess
        Finally
            'Close all connections.
            cnCustomerDB.Close()

            'Destroy all references.
            cnCustomerDB = Nothing
            cmdCustDetail = Nothing
            daCustDetail = Nothing
            parmTrackingNumber = Nothing
        End Try
    End Function
End Class
